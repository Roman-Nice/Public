﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SystemSounds
{
    /// <summary>
    /// bird
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click_Exl(object sender, RoutedEventArgs e)
        {
            System.Media.SystemSounds.Exclamation.Play(); 
            //potrebuje tenhle maxiodkaz bcs jsem tenhle projekt pojmenoval stejne jako SystemSound namespace xd
        }

        private void Button_Click_Hand(object sender, RoutedEventArgs e)
        {
            Button ThisButton = (Button)sender; // tradicni postup
            ThisButton.Background = Brushes.Red; //nejjednoduzsi zpusob jak nastavit background
            // object sender representuje objekt ze ktereho byla metoda Button_Click_Hand zavolana (jestli se chces zabivat do hloubky najdi si tema Delegati a jak se pouzivaji v Eventech{vymysl majkrosoftu})
            // muzeme tedy tahle nastavit backgroud buttonu ktery je zmacknut (v nasem pripade je metoda pouze na jednom buttonu takze by slo pracovat primo s nim ale jde o priklad)
            // alternativne tedy     Hand.Background = Brushes.Red;     (Hand je name property buttonu s textem "Hand neco") property x:Name (je to hack pro xaml hackery) si nevsimej ale bude ti fungovat stejne
            // jedna metoda muze byt prirazena vice buttonum
            System.Media.SystemSounds.Hand.Play();
            Hand.Background = Brushes.Red;
        }

        private void Button_Click_lol(object sender, RoutedEventArgs e)
        {
            System.Media.SystemSounds.Question.Play();
        }

        private void Button_Click_osm(object sender, RoutedEventArgs e)
        {
            System.Media.SystemSounds.Asterisk.Play();
        }

        private void Button_Click_Beep(object sender, RoutedEventArgs e)
        {
            System.Media.SystemSounds.Beep.Play();
        }
    }
}
