﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ZadaniKMaturite_1
{
    class Program
    {
        static StreamReader GetNumbers;
        static int NoItems = 0;
        static int[] RedNumbers;

        static void Main(string[] args)
        {
            if (args.Length == 1 && File.Exists(args[0]))
            {
                try
                {
                    GetNumbers = new StreamReader(args[0]);
                }
                catch (Exception)
                {
                    Console.WriteLine("Neplatna cesta k souboru");
                    Thread.Sleep(1000);
                    return;
                }
            }
            else
            {
                Console.WriteLine("Spatny pocet parametru / soubor neexistuje");
                Thread.Sleep(1000);
                return;
            }

            NoItems = GetNoItems();
            GetNumbers.Close();

            if (NoItems >= 40)
            {
                Console.WriteLine("Soubor je prilis velky");
                Thread.Sleep(1000);
                return;
            }

            RedNumbers = new int[NoItems];
            GetNumbers = new StreamReader(args[0]);
            for (int i = 0; i < NoItems; i++)
            {
                int.TryParse(GetNumbers.ReadLine(), out RedNumbers[i]);
            }
            GetNumbers.Close();

            RedNumbers = Sort(RedNumbers);
            foreach (var cislo in RedNumbers)
            {
                Console.WriteLine(cislo);
            }
            Asemble();
            Console.Read();

        }
        static void Asemble()
        {
            File.Create("export.html").Close();
            StreamWriter export = new StreamWriter("export.html");
            string Head = "<!DOCTYPE html>\n<head>\n<Style>\ndiv{\nbackground-color: red;\n height: 10px;\n}\n</Style>\n<title >lol</title>\n</head>\n<body>\n ";
            string End = "</body>";
            
            export.Write(Head);
            export.WriteLine("<H1>Export Dat</H1>");
            for (int i = 0; i < RedNumbers.Length; i++)
            {
                export.WriteLine($"<div style=\"width: {(RedNumbers[i] *100)}px\">\n<H3>{RedNumbers[i]}</H3>\n</div>");
                export.WriteLine("<br>");
            }
            export.WriteLine(End);
            export.Close();

        }
        static int[] Sort(int[] kocian)
        {
            for (int p = 0; p < kocian.Length; p++)
            {
                int AssumeBiggest = kocian[p];
                for (int i = p; i < kocian.Length; i++)
                {
                    if (AssumeBiggest < kocian[i])
                    {
                        kocian[p] = kocian[i];
                        kocian[i] = AssumeBiggest;
                        AssumeBiggest = kocian[p];
                    }
                }
            }
            return kocian;
        }
        static int GetNoItems()
        {
            string templine;
            int index = 0;
            while (true)
            {
                templine = GetNumbers.ReadLine();
                if (templine == null)
                {
                    GetNumbers.Close();
                    return index;
                }
                index++;
            }
        }
    }
}
