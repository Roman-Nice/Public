﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/// <summary>
/// hlavni vyuziti delegata je na komunikaci mezi prvky co k sobe normalne nemaji pristup udajne je vyuzivan ale ja ho nikdy nikde nevidel
/// delegat slouzi k predavani metod
/// zrejme mohou byt taky vyuzivany v async programovani ale tim jsem se nezabival
/// </summary>

namespace tuctuc
{
    public class Program
    {
        public delegate string priklad(decimal ci, decimal jm);

        static void Main(string[] args)
        {
            decimal citatel = 8;
            decimal jmenovatel = 6;
            Klasa cls = new Klasa();

            Func<decimal, decimal, string> Zbytek = (c, d) =>
            {
                if (c % d == 0)
                    return "bez zbytku";
                else
                    return "se zbytkem";
            }; //priklad vyuziti Func<>, obsah "()" je delegat metody s parametry c, d jejich typy jsou urceny v zavorce <> kde posledni parametr (v tomto pripade string) je return/out
            // v tuto chvili tedy existuje anonymni metoda ve tvaru  string bezJmena(decimal c, decimal d)
            // misto (c, d) muze byt jakykoliv delegat ale doporucuji zkozultovat microsoft docs o syntaxi
            // func musi mit vzdy navratovou hodnotu
            Console.WriteLine(Zbytek(citatel,jmenovatel)); 

            prijmaPriklad(cls.Method); //delegat typu priklad, classa cls ho nezajima dokud je metoda ve stejnem tvaru jako on
            // kdyz je metoda pouzita jako parametr tak se pise bez ()
            

            priklad tuc = cls.Method;
            prijmaPriklad(tuc);     //alternativa

            cls.Method(Sample); // priklad pouziti delegatna na zavolani private metody cls.Endemit


            Console.ReadLine();
        }

        static void prijmaPriklad(priklad Priklad)
        {
            Console.WriteLine("stalo se");            
        }
        static string Sample(decimal c, decimal jm)
        {
            return "Return value";
        }
    }

    public class Klasa : Program
    {
        public decimal Citatel { get; set; } = 5;
        public decimal Jmenovatel { get; set; } = 8;

        public string Method(decimal c, decimal jm) 
        {
            c = 5; jm = 8;
            Console.WriteLine("nestane se nikdy");
            return String.Format($"dokud je stejna jako delegat bude fungovat{c*jm}");
        }

        public string Method(priklad Priklad) 
        {
            Console.WriteLine("Zavolano z program");
            Endemit();
            return String.Format($"dokud je stejna jako delegat bude fungovat");
        }

        private void Endemit()
        {
            Console.WriteLine("prece jen");
        }
    }
}
