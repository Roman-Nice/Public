﻿using System;

namespace Ln
{
    class Program
    {
        static void Main(string[] args)
        {
            string Consequent;
            Log(Base: 2, Target: (2*2*2*2*2), out Consequent);
            Console.WriteLine("Exponent: "+Consequent);
        }
        static void Log(int Base, int Target, out string consequent)
        {
            int i = 1;
            int num = Base;
            do
            {
                i++;
                Base = Base * num;
                consequent = Base == Target ? consequent = (i).ToString() : Base > Target ? consequent = "no number like that" : null;
            } while ((consequent ??= "true") == "true");
        }
    }
}
