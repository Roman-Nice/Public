﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace MaturitaUkol2
{
    class Program
    {
        static int[] Mince = new int[] { 1, 2, 5, 10, 20, 50 };
        static void Main(string[] args)
        {
            string[] napoje = new string[] { "černá káva", "káva s mlékem", "káva irská", "čaj černý", "čaj ovocný" };
            int[] ceny = new int[] { 16, 18, 20, 16, 16 };

            string vstupUzivatel = "";
            string menu = "";
            int preplatek = 0;

            for (int i = 0; i < napoje.Length; i++)
            {
                menu += String.Format("({2}) napoj: {0} cena: {1}\n", napoje[i], ceny[i], i + 1);
            }
            menu += "(0) cancel\n";
            while (vstupUzivatel != "0")
            {
                Console.Clear();
                Console.WriteLine(menu);
                vstupUzivatel = Console.ReadLine();

                switch (vstupUzivatel)
                {
                    case "1":
                        preplatek = Platba(ceny[int.Parse(vstupUzivatel) - 1]);
                        break;
                    case "2":
                        preplatek = Platba(ceny[int.Parse(vstupUzivatel) - 1]);
                        break;
                    case "3":
                        preplatek = Platba(ceny[int.Parse(vstupUzivatel) - 1]);
                        break;
                    case "4":
                        preplatek = Platba(ceny[int.Parse(vstupUzivatel) - 1]);
                        break;
                    case "5":
                        preplatek = Platba(ceny[int.Parse(vstupUzivatel) - 1]);
                        break;

                    case "0":
                        Console.WriteLine("Nashledanou!");
                        Thread.Sleep(1000);
                        continue;
                    default:                       
                        Console.WriteLine("Spatne zadano!");
                        Thread.Sleep(1000);
                        continue;
                }
                Thread.Sleep(1000);
                Console.Clear();

                if (preplatek > 0)
                {
                    Vrat(preplatek);
                    Console.Clear();
                    Console.WriteLine("Dobrou chut!");
                    Thread.Sleep(2000);
                }
                else
                {
                    Console.WriteLine("Dobrou chut!");
                    Thread.Sleep(2000);
                }
            }
        }
        static void Vrat(int preplatek)
        {
            Console.WriteLine($"Bude vam vraceno {preplatek} korun");
            while (preplatek != 0)
            {
                if (preplatek > 50)
                {
                    Console.WriteLine("*Vraci 50*");
                    preplatek -= 50;
                }
                else if (preplatek > 20)
                {
                    Console.WriteLine("*Vraci 20*");
                    preplatek -= 20;
                }
                else if (preplatek > 10)
                {
                    Console.WriteLine("*Vraci 10*");
                    preplatek -= 10;
                }
                else if (preplatek > 5)
                {
                    Console.WriteLine("*Vraci 5*");
                    preplatek -= 5;
                }
                else if (preplatek >= 2)
                {
                    Console.WriteLine("*Vraci 2*");
                    preplatek -= 2;
                }
                else if (preplatek > 0)
                {
                    Console.WriteLine("*Vraci 1*");
                    preplatek -= 1;
                }
                Thread.Sleep(500);
            }
            Thread.Sleep(3000);
        }
        static int Platba(int cena)
        {
            int preplatek = 0;
            int mince;

            Console.Clear();
            Console.WriteLine("Prijmane mince");
            foreach (int prijmane in Mince)
            {
                Console.Write(prijmane + " ");
            }

            while (cena > 0)
            {
                Console.WriteLine("dluh: " + cena);
                int.TryParse(Console.ReadLine(), out mince);
                switch (mince)
                {
                    case 1:
                        cena -= 1;
                        break;
                    case 2:
                        cena -= 2;
                        break;
                    case 5:
                        cena -= 5;
                        break;
                    case 10:
                        cena -= 10;
                        break;
                    case 20:
                        cena -= 20;
                        break;
                    case 50:
                        cena -= 50;
                        break;

                    case 0:
                        cena -= 0;
                        break;
                    default:
                        cena -= 0;
                        break;
                }
            }
            if (cena < 0)
                preplatek = -cena;

            Console.WriteLine("Hned to bude...");
            return preplatek;
        }
    }
}
